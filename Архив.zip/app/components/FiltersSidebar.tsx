
import React from 'react';

const FiltersSidebar = () => {
  return (
    <aside className="bg-gray-100 p-4 h-full">
      <h2 className="text-lg font-semibold">Фильтры</h2>
    </aside>
  );
};

export default FiltersSidebar;
