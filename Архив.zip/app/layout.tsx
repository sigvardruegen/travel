// app/layout.tsx
import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Travel App',
  description: 'Find unique places to stay!',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru">
      <head>
        <link
          rel="stylesheet"
          href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
          integrity="sha256-pMnufH8Jw+iqF2ZFfFDDmSzA7s8C9sBt4tDzjvDGzLE="
          crossOrigin=""
        />
      </head>
      <body className="h-screen overflow-hidden">{children}</body>
    </html>
  );
}
