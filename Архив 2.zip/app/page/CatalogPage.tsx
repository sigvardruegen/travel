'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { CatalogItem } from '../lib/types';

const MapView = dynamic(() => import('../components/MapView'), { ssr: false });

export default function CatalogPage() {
  const [items, setItems] = useState<CatalogItem[]>([]);

  useEffect(() => {
    fetch('/api/catalog?bbox=20,50,60,80')
      .then(res => res.json())
      .then(data => {
        console.log("Fetched catalog items:", data.items);
        setItems(data.items);
      })
      .catch(err => console.error('Catalog fetch error', err));
  }, []);

  return (
    <main className="grid grid-cols-1 md:grid-cols-[1fr_400px] h-screen">
      <section className="overflow-y-auto p-4 h-full bg-white">
        <h1 className="text-xl font-bold">Каталог объектов</h1>
        <p>Тестовый текст</p>
      </section>
      <div className="h-full">
        <MapView items={items} />
      </div>
    </main>
  );
}
